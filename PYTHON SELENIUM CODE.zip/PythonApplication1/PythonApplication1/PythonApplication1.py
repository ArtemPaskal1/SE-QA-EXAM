﻿from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Инициализация драйвера браузера (в данном случае Chrome)
driver = webdriver.Chrome()

# Открытие страницы
driver.get("http://the-internet.herokuapp.com/dynamic_controls")

# Нахождение элементов чекбокса и кнопки "Remove"
checkbox = driver.find_element(By.ID, "checkbox")
remove_button = driver.find_element(By.XPATH, "//button[contains(text(), 'Remove')]")

# Проверка, что чекбокс присутствует и доступен для взаимодействия
if checkbox.is_displayed() and checkbox.is_enabled():
    print("Checkbox is present and enabled.")
else:
    print("Checkbox is not present or enabled.")

# Нажатие кнопки "Remove"
remove_button.click()

# Ожидание исчезновения чекбокса
WebDriverWait(driver, 10).until_not(EC.visibility_of_element_located((By.ID, "checkbox")))

# Проверка, что чекбокс исчез после удаления
if not checkbox.is_displayed():
    print("Checkbox is not present after removal.")
else:
    print("Checkbox is still present after removal.")

# Закрытие браузера
driver.quit()
